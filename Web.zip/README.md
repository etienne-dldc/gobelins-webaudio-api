# Etienne DLDC | Gobelins's creative workshop

## Lancer le projet

1. Installer les dépendances : `npm install`
2. Lacer le serveur : `npm run start:server`
3. Aller à l'adresse [http://localhost:9000]()
